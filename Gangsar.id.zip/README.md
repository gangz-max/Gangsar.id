# 🚀 Gangsar.id - Personal Portfolio (Dark Space Edition)

Website portfolio personal modern dengan estetika **Dark Mode Tema Luar Angkasa (Interstellar Space)**, efek **Glow Biru Neon (`#2c67ed`)**, animasi interaktif partikel kosmik/bintang jatuh, dan dibangun menggunakan stack teknologi modern:
- ⚛️ **React 18**
- 🎨 **Tailwind CSS**
- ✨ **Framer Motion** & Canvas Animations
- 💎 **Lucide React Icons**

---

## 🌟 Fitur Utama

1. **🌌 Background Luar Angkasa Interaktif (`SpaceBackground.jsx`)**:
   - 200+ bintang berkelip (*twinkling stars*) dengan kedalaman dinamis.
   - Bintang jatuh (*shooting meteors*) animasi real-time dengan jejak ekor cahaya biru & cyan.
   - Awan nebula kosmik berpendar dan respons interaktif gerakan kursor mouse (*parallax*).

2. **🛸 Navbar Melayang di Tengah Atas (`Navbar.jsx`)**:
   - Desain pill-shaped mengambang di tengah atas (*floating centered*).
   - Efek *frosted glass* (`backdrop-blur-xl`) dengan aksen border & glow biru neon `#2c67ed`.
   - Indikator tab aktif animasi yang mengikuti scroll pengguna (*scroll spy*).
   - Menu drawer navigasi responsif untuk perangkat mobile & tablet.

3. **🪐 Halaman Utama / Hero Section (`Hero.jsx`)**:
   - Tampilan nama besar berkilau kosmik.
   - **Teks mengetik otomatis (Typewriter Effect)** bergantian: `'Junior Developer'`, `'Tech Enthusiast'`, `'Frontend Specialist'`, `'Fullstack Explorer'`, `'UI/UX Enthusiast'`.
   - Tombol CTA *"Lihat Portfolio"*, *"Hubungi Saya"*, dan *"Resume / CV"*.
   - Orbit cincin kosmik & lencana status interaktif.

4. **🧑‍🚀 Section About Me (`About.jsx`)**:
   - Foto profil / avatar bergaya *high-tech astronaut* dengan *glowing nebula ring*.
   - Statistik pencapaian counter (*20+ Projects*, *12+ Collaborations*, *650+ Commits*, *15+ Tech Stacks*).
   - Sub-tab interaktif untuk **Pengalaman Kerja** (*timeline card & tags*) dan **Riwayat Pendidikan** (*detail institusi, GPA, & prestasi*).

5. **💼 Section Portfolio 3 Tab (`Portfolio.jsx`)**:
   - **Tab Projects**: Filter kategori (*All*, *Web App*, *Mobile/UI*, *Design*), kartu proyek dengan preview gambar, link Live Demo, tautan GitHub Repo, dan popup modal detail.
   - **Tab Certificates**: Sertifikasi kompetensi resmi dengan badge penerbit, tanggal, daftar skill terverifikasi, ID kredensial, dan tombol verifikasi.
   - **Tab Tech Stack**: Pengelompokan stack (*Frontend*, *Backend & Database*, *Tools & DevOps*), bar tingkat kemampuan (*proficiency percentage*) dengan gradien kosmik.

6. **📡 Section Kontak & Sosial Media (`Contact.jsx`)**:
   - Formulir pesan kosmik (*glassmorphism form*) dengan input glow aktif dan penanganan pengiriman.
   - Tombol satu-klik salin alamat email (*Quick Copy Email*) dengan konfirmasi status.
   - Tautan sosial media lengkap (*GitHub, LinkedIn, Instagram, Twitter/X, Discord*).

---

## 📁 Struktur Direktori

```
Gangsar.id/
├── index.html                 # Entry point Vite
├── preview.html               # File preview mandiri (dapat dibuka langsung di browser)
├── package.json               # Konfigurasi dependensi npm
├── vite.config.js             # Konfigurasi Vite
├── tailwind.config.js         # Konfigurasi tema warna kosmik & glow
├── postcss.config.js
├── README.md
└── src/
    ├── main.jsx               # Render React DOM
    ├── App.jsx                # Komponen Root
    ├── index.css              # Custom styling & scrollbar kosmik
    ├── data/
    │   └── portfolioData.js   # Seluruh data profil, proyek, sertifikat, & tech stack
    └── components/
        ├── SpaceBackground.jsx# Canvas animasi bintang, meteor & nebula
        ├── Navbar.jsx         # Navbar melayang glow biru
        ├── Hero.jsx           # Hero + Typewriter effect
        ├── About.jsx          # About me, profil, stats, edukasi & pengalaman
        ├── Portfolio.jsx      # Tab Projects, Certificates, & Tech Stack
        ├── Contact.jsx        # Form kontak & tautan sosial media
        └── Footer.jsx         # Footer & tombol Back to Orbit
```

---

## 🚀 Cara Menjalankan

### Opsi 1: Buka Langsung (Tanpa Node.js / NPM)
Cukup klik ganda (double-click) file [`preview.html`](file:///c:/Users/wijay/OneDrive/Documents/Gangsar.id/preview.html) di file explorer atau buka melalui browser (Google Chrome, Microsoft Edge, dll). Semua komponen, animasi, dan styling telah siap digunakan secara instan.

### Opsi 2: Menggunakan Vite Development Server
Jika Anda memiliki Node.js terpasang:
```bash
# 1. Install dependencies
npm install

# 2. Jalankan local development server
npm run dev

# 3. Build untuk produksi
npm run build
```

---

## ✏️ Kustomisasi Data Portofolio
Untuk mengubah nama, foto, biografi, daftar proyek, sertifikat, atau akun sosial media, Anda cukup mengedit satu file di:
👉 [`src/data/portfolioData.js`](file:///c:/Users/wijay/OneDrive/Documents/Gangsar.id/src/data/portfolioData.js)
